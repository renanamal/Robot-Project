### See https://github.com/luni64/TeensyTimerTool/wiki/Double-Exposure-Laser-Illuminator for a description of this example.
